﻿
namespace FinalProjectV1
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p05 = new System.Windows.Forms.Button();
            this.p06 = new System.Windows.Forms.Button();
            this.p09 = new System.Windows.Forms.Button();
            this.p08 = new System.Windows.Forms.Button();
            this.p07 = new System.Windows.Forms.Button();
            this.p02 = new System.Windows.Forms.Button();
            this.p03 = new System.Windows.Forms.Button();
            this.p04 = new System.Windows.Forms.Button();
            this.p01 = new System.Windows.Forms.Button();
            this.p00 = new System.Windows.Forms.Button();
            this.p12 = new System.Windows.Forms.Button();
            this.p13 = new System.Windows.Forms.Button();
            this.p14 = new System.Windows.Forms.Button();
            this.p11 = new System.Windows.Forms.Button();
            this.p10 = new System.Windows.Forms.Button();
            this.p17 = new System.Windows.Forms.Button();
            this.p18 = new System.Windows.Forms.Button();
            this.p19 = new System.Windows.Forms.Button();
            this.p16 = new System.Windows.Forms.Button();
            this.p15 = new System.Windows.Forms.Button();
            this.p22 = new System.Windows.Forms.Button();
            this.p23 = new System.Windows.Forms.Button();
            this.p24 = new System.Windows.Forms.Button();
            this.p21 = new System.Windows.Forms.Button();
            this.p20 = new System.Windows.Forms.Button();
            this.p27 = new System.Windows.Forms.Button();
            this.p28 = new System.Windows.Forms.Button();
            this.p29 = new System.Windows.Forms.Button();
            this.p26 = new System.Windows.Forms.Button();
            this.p25 = new System.Windows.Forms.Button();
            this.p32 = new System.Windows.Forms.Button();
            this.p33 = new System.Windows.Forms.Button();
            this.p34 = new System.Windows.Forms.Button();
            this.p31 = new System.Windows.Forms.Button();
            this.p30 = new System.Windows.Forms.Button();
            this.p37 = new System.Windows.Forms.Button();
            this.p38 = new System.Windows.Forms.Button();
            this.p39 = new System.Windows.Forms.Button();
            this.p36 = new System.Windows.Forms.Button();
            this.p35 = new System.Windows.Forms.Button();
            this.p42 = new System.Windows.Forms.Button();
            this.p43 = new System.Windows.Forms.Button();
            this.p44 = new System.Windows.Forms.Button();
            this.p41 = new System.Windows.Forms.Button();
            this.p40 = new System.Windows.Forms.Button();
            this.p47 = new System.Windows.Forms.Button();
            this.p48 = new System.Windows.Forms.Button();
            this.p49 = new System.Windows.Forms.Button();
            this.p46 = new System.Windows.Forms.Button();
            this.p45 = new System.Windows.Forms.Button();
            this.p52 = new System.Windows.Forms.Button();
            this.p53 = new System.Windows.Forms.Button();
            this.p54 = new System.Windows.Forms.Button();
            this.p51 = new System.Windows.Forms.Button();
            this.p50 = new System.Windows.Forms.Button();
            this.p57 = new System.Windows.Forms.Button();
            this.p58 = new System.Windows.Forms.Button();
            this.p59 = new System.Windows.Forms.Button();
            this.p56 = new System.Windows.Forms.Button();
            this.p55 = new System.Windows.Forms.Button();
            this.p62 = new System.Windows.Forms.Button();
            this.p63 = new System.Windows.Forms.Button();
            this.p64 = new System.Windows.Forms.Button();
            this.p61 = new System.Windows.Forms.Button();
            this.p60 = new System.Windows.Forms.Button();
            this.p67 = new System.Windows.Forms.Button();
            this.p68 = new System.Windows.Forms.Button();
            this.p69 = new System.Windows.Forms.Button();
            this.p66 = new System.Windows.Forms.Button();
            this.p65 = new System.Windows.Forms.Button();
            this.p72 = new System.Windows.Forms.Button();
            this.p73 = new System.Windows.Forms.Button();
            this.p74 = new System.Windows.Forms.Button();
            this.p71 = new System.Windows.Forms.Button();
            this.p70 = new System.Windows.Forms.Button();
            this.p77 = new System.Windows.Forms.Button();
            this.p78 = new System.Windows.Forms.Button();
            this.p79 = new System.Windows.Forms.Button();
            this.p76 = new System.Windows.Forms.Button();
            this.p75 = new System.Windows.Forms.Button();
            this.p82 = new System.Windows.Forms.Button();
            this.p83 = new System.Windows.Forms.Button();
            this.p84 = new System.Windows.Forms.Button();
            this.p81 = new System.Windows.Forms.Button();
            this.p80 = new System.Windows.Forms.Button();
            this.p87 = new System.Windows.Forms.Button();
            this.p88 = new System.Windows.Forms.Button();
            this.p89 = new System.Windows.Forms.Button();
            this.p86 = new System.Windows.Forms.Button();
            this.p85 = new System.Windows.Forms.Button();
            this.p92 = new System.Windows.Forms.Button();
            this.p93 = new System.Windows.Forms.Button();
            this.p94 = new System.Windows.Forms.Button();
            this.p91 = new System.Windows.Forms.Button();
            this.p90 = new System.Windows.Forms.Button();
            this.p97 = new System.Windows.Forms.Button();
            this.p98 = new System.Windows.Forms.Button();
            this.p99 = new System.Windows.Forms.Button();
            this.p96 = new System.Windows.Forms.Button();
            this.p95 = new System.Windows.Forms.Button();
            this.c92 = new System.Windows.Forms.Button();
            this.c93 = new System.Windows.Forms.Button();
            this.c94 = new System.Windows.Forms.Button();
            this.c91 = new System.Windows.Forms.Button();
            this.c90 = new System.Windows.Forms.Button();
            this.c97 = new System.Windows.Forms.Button();
            this.c98 = new System.Windows.Forms.Button();
            this.c99 = new System.Windows.Forms.Button();
            this.c96 = new System.Windows.Forms.Button();
            this.c95 = new System.Windows.Forms.Button();
            this.c82 = new System.Windows.Forms.Button();
            this.c83 = new System.Windows.Forms.Button();
            this.c84 = new System.Windows.Forms.Button();
            this.c81 = new System.Windows.Forms.Button();
            this.c80 = new System.Windows.Forms.Button();
            this.c87 = new System.Windows.Forms.Button();
            this.c88 = new System.Windows.Forms.Button();
            this.c89 = new System.Windows.Forms.Button();
            this.c86 = new System.Windows.Forms.Button();
            this.c85 = new System.Windows.Forms.Button();
            this.c72 = new System.Windows.Forms.Button();
            this.c73 = new System.Windows.Forms.Button();
            this.c74 = new System.Windows.Forms.Button();
            this.c71 = new System.Windows.Forms.Button();
            this.c70 = new System.Windows.Forms.Button();
            this.c77 = new System.Windows.Forms.Button();
            this.c78 = new System.Windows.Forms.Button();
            this.c79 = new System.Windows.Forms.Button();
            this.c76 = new System.Windows.Forms.Button();
            this.c75 = new System.Windows.Forms.Button();
            this.c62 = new System.Windows.Forms.Button();
            this.c63 = new System.Windows.Forms.Button();
            this.c64 = new System.Windows.Forms.Button();
            this.c61 = new System.Windows.Forms.Button();
            this.c60 = new System.Windows.Forms.Button();
            this.c67 = new System.Windows.Forms.Button();
            this.c68 = new System.Windows.Forms.Button();
            this.c69 = new System.Windows.Forms.Button();
            this.c66 = new System.Windows.Forms.Button();
            this.c65 = new System.Windows.Forms.Button();
            this.c52 = new System.Windows.Forms.Button();
            this.c53 = new System.Windows.Forms.Button();
            this.c54 = new System.Windows.Forms.Button();
            this.c51 = new System.Windows.Forms.Button();
            this.c50 = new System.Windows.Forms.Button();
            this.c57 = new System.Windows.Forms.Button();
            this.c58 = new System.Windows.Forms.Button();
            this.c59 = new System.Windows.Forms.Button();
            this.c56 = new System.Windows.Forms.Button();
            this.c55 = new System.Windows.Forms.Button();
            this.c42 = new System.Windows.Forms.Button();
            this.c43 = new System.Windows.Forms.Button();
            this.c44 = new System.Windows.Forms.Button();
            this.c41 = new System.Windows.Forms.Button();
            this.c40 = new System.Windows.Forms.Button();
            this.c47 = new System.Windows.Forms.Button();
            this.c48 = new System.Windows.Forms.Button();
            this.c49 = new System.Windows.Forms.Button();
            this.c46 = new System.Windows.Forms.Button();
            this.c45 = new System.Windows.Forms.Button();
            this.c32 = new System.Windows.Forms.Button();
            this.c33 = new System.Windows.Forms.Button();
            this.c34 = new System.Windows.Forms.Button();
            this.c31 = new System.Windows.Forms.Button();
            this.c30 = new System.Windows.Forms.Button();
            this.c37 = new System.Windows.Forms.Button();
            this.c38 = new System.Windows.Forms.Button();
            this.c39 = new System.Windows.Forms.Button();
            this.c36 = new System.Windows.Forms.Button();
            this.c35 = new System.Windows.Forms.Button();
            this.c22 = new System.Windows.Forms.Button();
            this.c23 = new System.Windows.Forms.Button();
            this.c24 = new System.Windows.Forms.Button();
            this.c21 = new System.Windows.Forms.Button();
            this.c20 = new System.Windows.Forms.Button();
            this.c27 = new System.Windows.Forms.Button();
            this.c28 = new System.Windows.Forms.Button();
            this.c29 = new System.Windows.Forms.Button();
            this.c26 = new System.Windows.Forms.Button();
            this.c25 = new System.Windows.Forms.Button();
            this.c12 = new System.Windows.Forms.Button();
            this.c13 = new System.Windows.Forms.Button();
            this.c14 = new System.Windows.Forms.Button();
            this.c11 = new System.Windows.Forms.Button();
            this.c10 = new System.Windows.Forms.Button();
            this.c17 = new System.Windows.Forms.Button();
            this.c18 = new System.Windows.Forms.Button();
            this.c19 = new System.Windows.Forms.Button();
            this.c16 = new System.Windows.Forms.Button();
            this.c15 = new System.Windows.Forms.Button();
            this.c02 = new System.Windows.Forms.Button();
            this.c03 = new System.Windows.Forms.Button();
            this.c04 = new System.Windows.Forms.Button();
            this.c01 = new System.Windows.Forms.Button();
            this.c00 = new System.Windows.Forms.Button();
            this.c07 = new System.Windows.Forms.Button();
            this.c08 = new System.Windows.Forms.Button();
            this.c09 = new System.Windows.Forms.Button();
            this.c06 = new System.Windows.Forms.Button();
            this.c05 = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCenter = new System.Windows.Forms.Label();
            this.lblRemain = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // p05
            // 
            this.p05.Location = new System.Drawing.Point(1118, 97);
            this.p05.Name = "p05";
            this.p05.Size = new System.Drawing.Size(40, 40);
            this.p05.TabIndex = 0;
            this.p05.UseVisualStyleBackColor = true;
            this.p05.Click += new System.EventHandler(this.btnClick);
            // 
            // p06
            // 
            this.p06.Location = new System.Drawing.Point(1164, 97);
            this.p06.Name = "p06";
            this.p06.Size = new System.Drawing.Size(40, 40);
            this.p06.TabIndex = 1;
            this.p06.UseVisualStyleBackColor = true;
            this.p06.Click += new System.EventHandler(this.btnClick);
            // 
            // p09
            // 
            this.p09.Location = new System.Drawing.Point(1302, 97);
            this.p09.Name = "p09";
            this.p09.Size = new System.Drawing.Size(40, 40);
            this.p09.TabIndex = 2;
            this.p09.UseVisualStyleBackColor = true;
            this.p09.Click += new System.EventHandler(this.btnClick);
            // 
            // p08
            // 
            this.p08.Location = new System.Drawing.Point(1256, 97);
            this.p08.Name = "p08";
            this.p08.Size = new System.Drawing.Size(40, 40);
            this.p08.TabIndex = 3;
            this.p08.UseVisualStyleBackColor = true;
            this.p08.Click += new System.EventHandler(this.btnClick);
            // 
            // p07
            // 
            this.p07.Location = new System.Drawing.Point(1210, 97);
            this.p07.Name = "p07";
            this.p07.Size = new System.Drawing.Size(40, 40);
            this.p07.TabIndex = 4;
            this.p07.UseVisualStyleBackColor = true;
            this.p07.Click += new System.EventHandler(this.btnClick);
            // 
            // p02
            // 
            this.p02.Location = new System.Drawing.Point(980, 97);
            this.p02.Name = "p02";
            this.p02.Size = new System.Drawing.Size(40, 40);
            this.p02.TabIndex = 9;
            this.p02.UseVisualStyleBackColor = true;
            this.p02.Click += new System.EventHandler(this.btnClick);
            // 
            // p03
            // 
            this.p03.Location = new System.Drawing.Point(1026, 97);
            this.p03.Name = "p03";
            this.p03.Size = new System.Drawing.Size(40, 40);
            this.p03.TabIndex = 8;
            this.p03.UseVisualStyleBackColor = true;
            this.p03.Click += new System.EventHandler(this.btnClick);
            // 
            // p04
            // 
            this.p04.Location = new System.Drawing.Point(1072, 97);
            this.p04.Name = "p04";
            this.p04.Size = new System.Drawing.Size(40, 40);
            this.p04.TabIndex = 7;
            this.p04.UseVisualStyleBackColor = true;
            this.p04.Click += new System.EventHandler(this.btnClick);
            // 
            // p01
            // 
            this.p01.Location = new System.Drawing.Point(934, 97);
            this.p01.Name = "p01";
            this.p01.Size = new System.Drawing.Size(40, 40);
            this.p01.TabIndex = 6;
            this.p01.UseVisualStyleBackColor = true;
            this.p01.Click += new System.EventHandler(this.btnClick);
            // 
            // p00
            // 
            this.p00.Location = new System.Drawing.Point(888, 97);
            this.p00.Name = "p00";
            this.p00.Size = new System.Drawing.Size(40, 40);
            this.p00.TabIndex = 5;
            this.p00.UseVisualStyleBackColor = true;
            this.p00.Click += new System.EventHandler(this.btnClick);
            // 
            // p12
            // 
            this.p12.Location = new System.Drawing.Point(980, 143);
            this.p12.Name = "p12";
            this.p12.Size = new System.Drawing.Size(40, 40);
            this.p12.TabIndex = 19;
            this.p12.UseVisualStyleBackColor = true;
            this.p12.Click += new System.EventHandler(this.btnClick);
            // 
            // p13
            // 
            this.p13.Location = new System.Drawing.Point(1026, 143);
            this.p13.Name = "p13";
            this.p13.Size = new System.Drawing.Size(40, 40);
            this.p13.TabIndex = 18;
            this.p13.UseVisualStyleBackColor = true;
            this.p13.Click += new System.EventHandler(this.btnClick);
            // 
            // p14
            // 
            this.p14.Location = new System.Drawing.Point(1072, 143);
            this.p14.Name = "p14";
            this.p14.Size = new System.Drawing.Size(40, 40);
            this.p14.TabIndex = 17;
            this.p14.UseVisualStyleBackColor = true;
            this.p14.Click += new System.EventHandler(this.btnClick);
            // 
            // p11
            // 
            this.p11.Location = new System.Drawing.Point(934, 143);
            this.p11.Name = "p11";
            this.p11.Size = new System.Drawing.Size(40, 40);
            this.p11.TabIndex = 16;
            this.p11.UseVisualStyleBackColor = true;
            this.p11.Click += new System.EventHandler(this.btnClick);
            // 
            // p10
            // 
            this.p10.Location = new System.Drawing.Point(888, 143);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(40, 40);
            this.p10.TabIndex = 15;
            this.p10.UseVisualStyleBackColor = true;
            this.p10.Click += new System.EventHandler(this.btnClick);
            // 
            // p17
            // 
            this.p17.Location = new System.Drawing.Point(1210, 143);
            this.p17.Name = "p17";
            this.p17.Size = new System.Drawing.Size(40, 40);
            this.p17.TabIndex = 14;
            this.p17.UseVisualStyleBackColor = true;
            this.p17.Click += new System.EventHandler(this.btnClick);
            // 
            // p18
            // 
            this.p18.Location = new System.Drawing.Point(1256, 143);
            this.p18.Name = "p18";
            this.p18.Size = new System.Drawing.Size(40, 40);
            this.p18.TabIndex = 13;
            this.p18.UseVisualStyleBackColor = true;
            this.p18.Click += new System.EventHandler(this.btnClick);
            // 
            // p19
            // 
            this.p19.Location = new System.Drawing.Point(1302, 143);
            this.p19.Name = "p19";
            this.p19.Size = new System.Drawing.Size(40, 40);
            this.p19.TabIndex = 12;
            this.p19.UseVisualStyleBackColor = true;
            this.p19.Click += new System.EventHandler(this.btnClick);
            // 
            // p16
            // 
            this.p16.Location = new System.Drawing.Point(1164, 143);
            this.p16.Name = "p16";
            this.p16.Size = new System.Drawing.Size(40, 40);
            this.p16.TabIndex = 11;
            this.p16.UseVisualStyleBackColor = true;
            this.p16.Click += new System.EventHandler(this.btnClick);
            // 
            // p15
            // 
            this.p15.Location = new System.Drawing.Point(1118, 143);
            this.p15.Name = "p15";
            this.p15.Size = new System.Drawing.Size(40, 40);
            this.p15.TabIndex = 10;
            this.p15.UseVisualStyleBackColor = true;
            this.p15.Click += new System.EventHandler(this.btnClick);
            // 
            // p22
            // 
            this.p22.Location = new System.Drawing.Point(980, 189);
            this.p22.Name = "p22";
            this.p22.Size = new System.Drawing.Size(40, 40);
            this.p22.TabIndex = 29;
            this.p22.UseVisualStyleBackColor = true;
            this.p22.Click += new System.EventHandler(this.btnClick);
            // 
            // p23
            // 
            this.p23.Location = new System.Drawing.Point(1026, 189);
            this.p23.Name = "p23";
            this.p23.Size = new System.Drawing.Size(40, 40);
            this.p23.TabIndex = 28;
            this.p23.UseVisualStyleBackColor = true;
            this.p23.Click += new System.EventHandler(this.btnClick);
            // 
            // p24
            // 
            this.p24.Location = new System.Drawing.Point(1072, 189);
            this.p24.Name = "p24";
            this.p24.Size = new System.Drawing.Size(40, 40);
            this.p24.TabIndex = 27;
            this.p24.UseVisualStyleBackColor = true;
            this.p24.Click += new System.EventHandler(this.btnClick);
            // 
            // p21
            // 
            this.p21.Location = new System.Drawing.Point(934, 189);
            this.p21.Name = "p21";
            this.p21.Size = new System.Drawing.Size(40, 40);
            this.p21.TabIndex = 26;
            this.p21.UseVisualStyleBackColor = true;
            this.p21.Click += new System.EventHandler(this.btnClick);
            // 
            // p20
            // 
            this.p20.Location = new System.Drawing.Point(888, 189);
            this.p20.Name = "p20";
            this.p20.Size = new System.Drawing.Size(40, 40);
            this.p20.TabIndex = 25;
            this.p20.UseVisualStyleBackColor = true;
            this.p20.Click += new System.EventHandler(this.btnClick);
            // 
            // p27
            // 
            this.p27.Location = new System.Drawing.Point(1210, 189);
            this.p27.Name = "p27";
            this.p27.Size = new System.Drawing.Size(40, 40);
            this.p27.TabIndex = 24;
            this.p27.UseVisualStyleBackColor = true;
            this.p27.Click += new System.EventHandler(this.btnClick);
            // 
            // p28
            // 
            this.p28.Location = new System.Drawing.Point(1256, 189);
            this.p28.Name = "p28";
            this.p28.Size = new System.Drawing.Size(40, 40);
            this.p28.TabIndex = 23;
            this.p28.UseVisualStyleBackColor = true;
            this.p28.Click += new System.EventHandler(this.btnClick);
            // 
            // p29
            // 
            this.p29.Location = new System.Drawing.Point(1302, 189);
            this.p29.Name = "p29";
            this.p29.Size = new System.Drawing.Size(40, 40);
            this.p29.TabIndex = 22;
            this.p29.UseVisualStyleBackColor = true;
            this.p29.Click += new System.EventHandler(this.btnClick);
            // 
            // p26
            // 
            this.p26.Location = new System.Drawing.Point(1164, 189);
            this.p26.Name = "p26";
            this.p26.Size = new System.Drawing.Size(40, 40);
            this.p26.TabIndex = 21;
            this.p26.UseVisualStyleBackColor = true;
            this.p26.Click += new System.EventHandler(this.btnClick);
            // 
            // p25
            // 
            this.p25.Location = new System.Drawing.Point(1118, 189);
            this.p25.Name = "p25";
            this.p25.Size = new System.Drawing.Size(40, 40);
            this.p25.TabIndex = 20;
            this.p25.UseVisualStyleBackColor = true;
            this.p25.Click += new System.EventHandler(this.btnClick);
            // 
            // p32
            // 
            this.p32.Location = new System.Drawing.Point(980, 235);
            this.p32.Name = "p32";
            this.p32.Size = new System.Drawing.Size(40, 40);
            this.p32.TabIndex = 39;
            this.p32.UseVisualStyleBackColor = true;
            this.p32.Click += new System.EventHandler(this.btnClick);
            // 
            // p33
            // 
            this.p33.Location = new System.Drawing.Point(1026, 235);
            this.p33.Name = "p33";
            this.p33.Size = new System.Drawing.Size(40, 40);
            this.p33.TabIndex = 38;
            this.p33.UseVisualStyleBackColor = true;
            this.p33.Click += new System.EventHandler(this.btnClick);
            // 
            // p34
            // 
            this.p34.Location = new System.Drawing.Point(1072, 235);
            this.p34.Name = "p34";
            this.p34.Size = new System.Drawing.Size(40, 40);
            this.p34.TabIndex = 37;
            this.p34.UseVisualStyleBackColor = true;
            this.p34.Click += new System.EventHandler(this.btnClick);
            // 
            // p31
            // 
            this.p31.Location = new System.Drawing.Point(934, 235);
            this.p31.Name = "p31";
            this.p31.Size = new System.Drawing.Size(40, 40);
            this.p31.TabIndex = 36;
            this.p31.UseVisualStyleBackColor = true;
            this.p31.Click += new System.EventHandler(this.btnClick);
            // 
            // p30
            // 
            this.p30.Location = new System.Drawing.Point(888, 235);
            this.p30.Name = "p30";
            this.p30.Size = new System.Drawing.Size(40, 40);
            this.p30.TabIndex = 35;
            this.p30.UseVisualStyleBackColor = true;
            this.p30.Click += new System.EventHandler(this.btnClick);
            // 
            // p37
            // 
            this.p37.Location = new System.Drawing.Point(1210, 235);
            this.p37.Name = "p37";
            this.p37.Size = new System.Drawing.Size(40, 40);
            this.p37.TabIndex = 34;
            this.p37.UseVisualStyleBackColor = true;
            this.p37.Click += new System.EventHandler(this.btnClick);
            // 
            // p38
            // 
            this.p38.Location = new System.Drawing.Point(1256, 235);
            this.p38.Name = "p38";
            this.p38.Size = new System.Drawing.Size(40, 40);
            this.p38.TabIndex = 33;
            this.p38.UseVisualStyleBackColor = true;
            this.p38.Click += new System.EventHandler(this.btnClick);
            // 
            // p39
            // 
            this.p39.Location = new System.Drawing.Point(1302, 235);
            this.p39.Name = "p39";
            this.p39.Size = new System.Drawing.Size(40, 40);
            this.p39.TabIndex = 32;
            this.p39.UseVisualStyleBackColor = true;
            this.p39.Click += new System.EventHandler(this.btnClick);
            // 
            // p36
            // 
            this.p36.Location = new System.Drawing.Point(1164, 235);
            this.p36.Name = "p36";
            this.p36.Size = new System.Drawing.Size(40, 40);
            this.p36.TabIndex = 31;
            this.p36.UseVisualStyleBackColor = true;
            this.p36.Click += new System.EventHandler(this.btnClick);
            // 
            // p35
            // 
            this.p35.Location = new System.Drawing.Point(1118, 235);
            this.p35.Name = "p35";
            this.p35.Size = new System.Drawing.Size(40, 40);
            this.p35.TabIndex = 30;
            this.p35.UseVisualStyleBackColor = true;
            this.p35.Click += new System.EventHandler(this.btnClick);
            // 
            // p42
            // 
            this.p42.Location = new System.Drawing.Point(980, 281);
            this.p42.Name = "p42";
            this.p42.Size = new System.Drawing.Size(40, 40);
            this.p42.TabIndex = 49;
            this.p42.UseVisualStyleBackColor = true;
            this.p42.Click += new System.EventHandler(this.btnClick);
            // 
            // p43
            // 
            this.p43.Location = new System.Drawing.Point(1026, 281);
            this.p43.Name = "p43";
            this.p43.Size = new System.Drawing.Size(40, 40);
            this.p43.TabIndex = 48;
            this.p43.UseVisualStyleBackColor = true;
            this.p43.Click += new System.EventHandler(this.btnClick);
            // 
            // p44
            // 
            this.p44.Location = new System.Drawing.Point(1072, 281);
            this.p44.Name = "p44";
            this.p44.Size = new System.Drawing.Size(40, 40);
            this.p44.TabIndex = 47;
            this.p44.UseVisualStyleBackColor = true;
            this.p44.Click += new System.EventHandler(this.btnClick);
            // 
            // p41
            // 
            this.p41.Location = new System.Drawing.Point(934, 281);
            this.p41.Name = "p41";
            this.p41.Size = new System.Drawing.Size(40, 40);
            this.p41.TabIndex = 46;
            this.p41.UseVisualStyleBackColor = true;
            this.p41.Click += new System.EventHandler(this.btnClick);
            // 
            // p40
            // 
            this.p40.Location = new System.Drawing.Point(888, 281);
            this.p40.Name = "p40";
            this.p40.Size = new System.Drawing.Size(40, 40);
            this.p40.TabIndex = 45;
            this.p40.UseVisualStyleBackColor = true;
            this.p40.Click += new System.EventHandler(this.btnClick);
            // 
            // p47
            // 
            this.p47.Location = new System.Drawing.Point(1210, 281);
            this.p47.Name = "p47";
            this.p47.Size = new System.Drawing.Size(40, 40);
            this.p47.TabIndex = 44;
            this.p47.UseVisualStyleBackColor = true;
            this.p47.Click += new System.EventHandler(this.btnClick);
            // 
            // p48
            // 
            this.p48.Location = new System.Drawing.Point(1256, 281);
            this.p48.Name = "p48";
            this.p48.Size = new System.Drawing.Size(40, 40);
            this.p48.TabIndex = 43;
            this.p48.UseVisualStyleBackColor = true;
            this.p48.Click += new System.EventHandler(this.btnClick);
            // 
            // p49
            // 
            this.p49.Location = new System.Drawing.Point(1302, 281);
            this.p49.Name = "p49";
            this.p49.Size = new System.Drawing.Size(40, 40);
            this.p49.TabIndex = 42;
            this.p49.UseVisualStyleBackColor = true;
            this.p49.Click += new System.EventHandler(this.btnClick);
            // 
            // p46
            // 
            this.p46.Location = new System.Drawing.Point(1164, 281);
            this.p46.Name = "p46";
            this.p46.Size = new System.Drawing.Size(40, 40);
            this.p46.TabIndex = 41;
            this.p46.UseVisualStyleBackColor = true;
            this.p46.Click += new System.EventHandler(this.btnClick);
            // 
            // p45
            // 
            this.p45.Location = new System.Drawing.Point(1118, 281);
            this.p45.Name = "p45";
            this.p45.Size = new System.Drawing.Size(40, 40);
            this.p45.TabIndex = 40;
            this.p45.UseVisualStyleBackColor = true;
            this.p45.Click += new System.EventHandler(this.btnClick);
            // 
            // p52
            // 
            this.p52.Location = new System.Drawing.Point(980, 327);
            this.p52.Name = "p52";
            this.p52.Size = new System.Drawing.Size(40, 40);
            this.p52.TabIndex = 59;
            this.p52.UseVisualStyleBackColor = true;
            this.p52.Click += new System.EventHandler(this.btnClick);
            // 
            // p53
            // 
            this.p53.Location = new System.Drawing.Point(1026, 327);
            this.p53.Name = "p53";
            this.p53.Size = new System.Drawing.Size(40, 40);
            this.p53.TabIndex = 58;
            this.p53.UseVisualStyleBackColor = true;
            this.p53.Click += new System.EventHandler(this.btnClick);
            // 
            // p54
            // 
            this.p54.Location = new System.Drawing.Point(1072, 327);
            this.p54.Name = "p54";
            this.p54.Size = new System.Drawing.Size(40, 40);
            this.p54.TabIndex = 57;
            this.p54.UseVisualStyleBackColor = true;
            this.p54.Click += new System.EventHandler(this.btnClick);
            // 
            // p51
            // 
            this.p51.Location = new System.Drawing.Point(934, 327);
            this.p51.Name = "p51";
            this.p51.Size = new System.Drawing.Size(40, 40);
            this.p51.TabIndex = 56;
            this.p51.UseVisualStyleBackColor = true;
            this.p51.Click += new System.EventHandler(this.btnClick);
            // 
            // p50
            // 
            this.p50.Location = new System.Drawing.Point(888, 327);
            this.p50.Name = "p50";
            this.p50.Size = new System.Drawing.Size(40, 40);
            this.p50.TabIndex = 55;
            this.p50.UseVisualStyleBackColor = true;
            this.p50.Click += new System.EventHandler(this.btnClick);
            // 
            // p57
            // 
            this.p57.Location = new System.Drawing.Point(1210, 327);
            this.p57.Name = "p57";
            this.p57.Size = new System.Drawing.Size(40, 40);
            this.p57.TabIndex = 54;
            this.p57.UseVisualStyleBackColor = true;
            this.p57.Click += new System.EventHandler(this.btnClick);
            // 
            // p58
            // 
            this.p58.Location = new System.Drawing.Point(1256, 327);
            this.p58.Name = "p58";
            this.p58.Size = new System.Drawing.Size(40, 40);
            this.p58.TabIndex = 53;
            this.p58.UseVisualStyleBackColor = true;
            this.p58.Click += new System.EventHandler(this.btnClick);
            // 
            // p59
            // 
            this.p59.Location = new System.Drawing.Point(1302, 327);
            this.p59.Name = "p59";
            this.p59.Size = new System.Drawing.Size(40, 40);
            this.p59.TabIndex = 52;
            this.p59.UseVisualStyleBackColor = true;
            this.p59.Click += new System.EventHandler(this.btnClick);
            // 
            // p56
            // 
            this.p56.Location = new System.Drawing.Point(1164, 327);
            this.p56.Name = "p56";
            this.p56.Size = new System.Drawing.Size(40, 40);
            this.p56.TabIndex = 51;
            this.p56.UseVisualStyleBackColor = true;
            this.p56.Click += new System.EventHandler(this.btnClick);
            // 
            // p55
            // 
            this.p55.Location = new System.Drawing.Point(1118, 327);
            this.p55.Name = "p55";
            this.p55.Size = new System.Drawing.Size(40, 40);
            this.p55.TabIndex = 50;
            this.p55.UseVisualStyleBackColor = true;
            this.p55.Click += new System.EventHandler(this.btnClick);
            // 
            // p62
            // 
            this.p62.Location = new System.Drawing.Point(980, 373);
            this.p62.Name = "p62";
            this.p62.Size = new System.Drawing.Size(40, 40);
            this.p62.TabIndex = 69;
            this.p62.UseVisualStyleBackColor = true;
            this.p62.Click += new System.EventHandler(this.btnClick);
            // 
            // p63
            // 
            this.p63.Location = new System.Drawing.Point(1026, 373);
            this.p63.Name = "p63";
            this.p63.Size = new System.Drawing.Size(40, 40);
            this.p63.TabIndex = 68;
            this.p63.UseVisualStyleBackColor = true;
            this.p63.Click += new System.EventHandler(this.btnClick);
            // 
            // p64
            // 
            this.p64.Location = new System.Drawing.Point(1072, 373);
            this.p64.Name = "p64";
            this.p64.Size = new System.Drawing.Size(40, 40);
            this.p64.TabIndex = 67;
            this.p64.UseVisualStyleBackColor = true;
            this.p64.Click += new System.EventHandler(this.btnClick);
            // 
            // p61
            // 
            this.p61.Location = new System.Drawing.Point(934, 373);
            this.p61.Name = "p61";
            this.p61.Size = new System.Drawing.Size(40, 40);
            this.p61.TabIndex = 66;
            this.p61.UseVisualStyleBackColor = true;
            this.p61.Click += new System.EventHandler(this.btnClick);
            // 
            // p60
            // 
            this.p60.Location = new System.Drawing.Point(888, 373);
            this.p60.Name = "p60";
            this.p60.Size = new System.Drawing.Size(40, 40);
            this.p60.TabIndex = 65;
            this.p60.UseVisualStyleBackColor = true;
            this.p60.Click += new System.EventHandler(this.btnClick);
            // 
            // p67
            // 
            this.p67.Location = new System.Drawing.Point(1210, 373);
            this.p67.Name = "p67";
            this.p67.Size = new System.Drawing.Size(40, 40);
            this.p67.TabIndex = 64;
            this.p67.UseVisualStyleBackColor = true;
            this.p67.Click += new System.EventHandler(this.btnClick);
            // 
            // p68
            // 
            this.p68.Location = new System.Drawing.Point(1256, 373);
            this.p68.Name = "p68";
            this.p68.Size = new System.Drawing.Size(40, 40);
            this.p68.TabIndex = 63;
            this.p68.UseVisualStyleBackColor = true;
            this.p68.Click += new System.EventHandler(this.btnClick);
            // 
            // p69
            // 
            this.p69.Location = new System.Drawing.Point(1302, 373);
            this.p69.Name = "p69";
            this.p69.Size = new System.Drawing.Size(40, 40);
            this.p69.TabIndex = 62;
            this.p69.UseVisualStyleBackColor = true;
            this.p69.Click += new System.EventHandler(this.btnClick);
            // 
            // p66
            // 
            this.p66.Location = new System.Drawing.Point(1164, 373);
            this.p66.Name = "p66";
            this.p66.Size = new System.Drawing.Size(40, 40);
            this.p66.TabIndex = 61;
            this.p66.UseVisualStyleBackColor = true;
            this.p66.Click += new System.EventHandler(this.btnClick);
            // 
            // p65
            // 
            this.p65.Location = new System.Drawing.Point(1118, 373);
            this.p65.Name = "p65";
            this.p65.Size = new System.Drawing.Size(40, 40);
            this.p65.TabIndex = 60;
            this.p65.UseVisualStyleBackColor = true;
            this.p65.Click += new System.EventHandler(this.btnClick);
            // 
            // p72
            // 
            this.p72.Location = new System.Drawing.Point(980, 419);
            this.p72.Name = "p72";
            this.p72.Size = new System.Drawing.Size(40, 40);
            this.p72.TabIndex = 79;
            this.p72.UseVisualStyleBackColor = true;
            this.p72.Click += new System.EventHandler(this.btnClick);
            // 
            // p73
            // 
            this.p73.Location = new System.Drawing.Point(1026, 419);
            this.p73.Name = "p73";
            this.p73.Size = new System.Drawing.Size(40, 40);
            this.p73.TabIndex = 78;
            this.p73.UseVisualStyleBackColor = true;
            this.p73.Click += new System.EventHandler(this.btnClick);
            // 
            // p74
            // 
            this.p74.Location = new System.Drawing.Point(1072, 419);
            this.p74.Name = "p74";
            this.p74.Size = new System.Drawing.Size(40, 40);
            this.p74.TabIndex = 77;
            this.p74.UseVisualStyleBackColor = true;
            this.p74.Click += new System.EventHandler(this.btnClick);
            // 
            // p71
            // 
            this.p71.Location = new System.Drawing.Point(934, 419);
            this.p71.Name = "p71";
            this.p71.Size = new System.Drawing.Size(40, 40);
            this.p71.TabIndex = 76;
            this.p71.UseVisualStyleBackColor = true;
            this.p71.Click += new System.EventHandler(this.btnClick);
            // 
            // p70
            // 
            this.p70.Location = new System.Drawing.Point(888, 419);
            this.p70.Name = "p70";
            this.p70.Size = new System.Drawing.Size(40, 40);
            this.p70.TabIndex = 75;
            this.p70.UseVisualStyleBackColor = true;
            this.p70.Click += new System.EventHandler(this.btnClick);
            // 
            // p77
            // 
            this.p77.Location = new System.Drawing.Point(1210, 419);
            this.p77.Name = "p77";
            this.p77.Size = new System.Drawing.Size(40, 40);
            this.p77.TabIndex = 74;
            this.p77.UseVisualStyleBackColor = true;
            this.p77.Click += new System.EventHandler(this.btnClick);
            // 
            // p78
            // 
            this.p78.Location = new System.Drawing.Point(1256, 419);
            this.p78.Name = "p78";
            this.p78.Size = new System.Drawing.Size(40, 40);
            this.p78.TabIndex = 73;
            this.p78.UseVisualStyleBackColor = true;
            this.p78.Click += new System.EventHandler(this.btnClick);
            // 
            // p79
            // 
            this.p79.Location = new System.Drawing.Point(1302, 419);
            this.p79.Name = "p79";
            this.p79.Size = new System.Drawing.Size(40, 40);
            this.p79.TabIndex = 72;
            this.p79.UseVisualStyleBackColor = true;
            this.p79.Click += new System.EventHandler(this.btnClick);
            // 
            // p76
            // 
            this.p76.Location = new System.Drawing.Point(1164, 419);
            this.p76.Name = "p76";
            this.p76.Size = new System.Drawing.Size(40, 40);
            this.p76.TabIndex = 71;
            this.p76.UseVisualStyleBackColor = true;
            this.p76.Click += new System.EventHandler(this.btnClick);
            // 
            // p75
            // 
            this.p75.Location = new System.Drawing.Point(1118, 419);
            this.p75.Name = "p75";
            this.p75.Size = new System.Drawing.Size(40, 40);
            this.p75.TabIndex = 70;
            this.p75.UseVisualStyleBackColor = true;
            this.p75.Click += new System.EventHandler(this.btnClick);
            // 
            // p82
            // 
            this.p82.Location = new System.Drawing.Point(980, 465);
            this.p82.Name = "p82";
            this.p82.Size = new System.Drawing.Size(40, 40);
            this.p82.TabIndex = 89;
            this.p82.UseVisualStyleBackColor = true;
            this.p82.Click += new System.EventHandler(this.btnClick);
            // 
            // p83
            // 
            this.p83.Location = new System.Drawing.Point(1026, 465);
            this.p83.Name = "p83";
            this.p83.Size = new System.Drawing.Size(40, 40);
            this.p83.TabIndex = 88;
            this.p83.UseVisualStyleBackColor = true;
            this.p83.Click += new System.EventHandler(this.btnClick);
            // 
            // p84
            // 
            this.p84.Location = new System.Drawing.Point(1072, 465);
            this.p84.Name = "p84";
            this.p84.Size = new System.Drawing.Size(40, 40);
            this.p84.TabIndex = 87;
            this.p84.UseVisualStyleBackColor = true;
            this.p84.Click += new System.EventHandler(this.btnClick);
            // 
            // p81
            // 
            this.p81.Location = new System.Drawing.Point(934, 465);
            this.p81.Name = "p81";
            this.p81.Size = new System.Drawing.Size(40, 40);
            this.p81.TabIndex = 86;
            this.p81.UseVisualStyleBackColor = true;
            this.p81.Click += new System.EventHandler(this.btnClick);
            // 
            // p80
            // 
            this.p80.Location = new System.Drawing.Point(888, 465);
            this.p80.Name = "p80";
            this.p80.Size = new System.Drawing.Size(40, 40);
            this.p80.TabIndex = 85;
            this.p80.UseVisualStyleBackColor = true;
            this.p80.Click += new System.EventHandler(this.btnClick);
            // 
            // p87
            // 
            this.p87.Location = new System.Drawing.Point(1210, 465);
            this.p87.Name = "p87";
            this.p87.Size = new System.Drawing.Size(40, 40);
            this.p87.TabIndex = 84;
            this.p87.UseVisualStyleBackColor = true;
            this.p87.Click += new System.EventHandler(this.btnClick);
            // 
            // p88
            // 
            this.p88.Location = new System.Drawing.Point(1256, 465);
            this.p88.Name = "p88";
            this.p88.Size = new System.Drawing.Size(40, 40);
            this.p88.TabIndex = 83;
            this.p88.UseVisualStyleBackColor = true;
            this.p88.Click += new System.EventHandler(this.btnClick);
            // 
            // p89
            // 
            this.p89.Location = new System.Drawing.Point(1302, 465);
            this.p89.Name = "p89";
            this.p89.Size = new System.Drawing.Size(40, 40);
            this.p89.TabIndex = 82;
            this.p89.UseVisualStyleBackColor = true;
            this.p89.Click += new System.EventHandler(this.btnClick);
            // 
            // p86
            // 
            this.p86.Location = new System.Drawing.Point(1164, 465);
            this.p86.Name = "p86";
            this.p86.Size = new System.Drawing.Size(40, 40);
            this.p86.TabIndex = 81;
            this.p86.UseVisualStyleBackColor = true;
            this.p86.Click += new System.EventHandler(this.btnClick);
            // 
            // p85
            // 
            this.p85.Location = new System.Drawing.Point(1118, 465);
            this.p85.Name = "p85";
            this.p85.Size = new System.Drawing.Size(40, 40);
            this.p85.TabIndex = 80;
            this.p85.UseVisualStyleBackColor = true;
            this.p85.Click += new System.EventHandler(this.btnClick);
            // 
            // p92
            // 
            this.p92.Location = new System.Drawing.Point(980, 511);
            this.p92.Name = "p92";
            this.p92.Size = new System.Drawing.Size(40, 40);
            this.p92.TabIndex = 99;
            this.p92.UseVisualStyleBackColor = true;
            this.p92.Click += new System.EventHandler(this.btnClick);
            // 
            // p93
            // 
            this.p93.Location = new System.Drawing.Point(1026, 511);
            this.p93.Name = "p93";
            this.p93.Size = new System.Drawing.Size(40, 40);
            this.p93.TabIndex = 98;
            this.p93.UseVisualStyleBackColor = true;
            this.p93.Click += new System.EventHandler(this.btnClick);
            // 
            // p94
            // 
            this.p94.Location = new System.Drawing.Point(1072, 511);
            this.p94.Name = "p94";
            this.p94.Size = new System.Drawing.Size(40, 40);
            this.p94.TabIndex = 97;
            this.p94.UseVisualStyleBackColor = true;
            this.p94.Click += new System.EventHandler(this.btnClick);
            // 
            // p91
            // 
            this.p91.Location = new System.Drawing.Point(934, 511);
            this.p91.Name = "p91";
            this.p91.Size = new System.Drawing.Size(40, 40);
            this.p91.TabIndex = 96;
            this.p91.UseVisualStyleBackColor = true;
            this.p91.Click += new System.EventHandler(this.btnClick);
            // 
            // p90
            // 
            this.p90.Location = new System.Drawing.Point(888, 511);
            this.p90.Name = "p90";
            this.p90.Size = new System.Drawing.Size(40, 40);
            this.p90.TabIndex = 95;
            this.p90.UseVisualStyleBackColor = true;
            this.p90.Click += new System.EventHandler(this.btnClick);
            // 
            // p97
            // 
            this.p97.Location = new System.Drawing.Point(1210, 511);
            this.p97.Name = "p97";
            this.p97.Size = new System.Drawing.Size(40, 40);
            this.p97.TabIndex = 94;
            this.p97.UseVisualStyleBackColor = true;
            this.p97.Click += new System.EventHandler(this.btnClick);
            // 
            // p98
            // 
            this.p98.Location = new System.Drawing.Point(1256, 511);
            this.p98.Name = "p98";
            this.p98.Size = new System.Drawing.Size(40, 40);
            this.p98.TabIndex = 93;
            this.p98.UseVisualStyleBackColor = true;
            this.p98.Click += new System.EventHandler(this.btnClick);
            // 
            // p99
            // 
            this.p99.Location = new System.Drawing.Point(1302, 511);
            this.p99.Name = "p99";
            this.p99.Size = new System.Drawing.Size(40, 40);
            this.p99.TabIndex = 92;
            this.p99.UseVisualStyleBackColor = true;
            this.p99.Click += new System.EventHandler(this.btnClick);
            // 
            // p96
            // 
            this.p96.Location = new System.Drawing.Point(1164, 511);
            this.p96.Name = "p96";
            this.p96.Size = new System.Drawing.Size(40, 40);
            this.p96.TabIndex = 91;
            this.p96.UseVisualStyleBackColor = true;
            this.p96.Click += new System.EventHandler(this.btnClick);
            // 
            // p95
            // 
            this.p95.Location = new System.Drawing.Point(1118, 511);
            this.p95.Name = "p95";
            this.p95.Size = new System.Drawing.Size(40, 40);
            this.p95.TabIndex = 90;
            this.p95.UseVisualStyleBackColor = true;
            this.p95.Click += new System.EventHandler(this.btnClick);
            // 
            // c92
            // 
            this.c92.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c92.Location = new System.Drawing.Point(112, 511);
            this.c92.Name = "c92";
            this.c92.Size = new System.Drawing.Size(40, 40);
            this.c92.TabIndex = 199;
            this.c92.UseVisualStyleBackColor = true;
            this.c92.Click += new System.EventHandler(this.GuessClick);
            // 
            // c93
            // 
            this.c93.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c93.Location = new System.Drawing.Point(158, 511);
            this.c93.Name = "c93";
            this.c93.Size = new System.Drawing.Size(40, 40);
            this.c93.TabIndex = 198;
            this.c93.UseVisualStyleBackColor = true;
            this.c93.Click += new System.EventHandler(this.GuessClick);
            // 
            // c94
            // 
            this.c94.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c94.Location = new System.Drawing.Point(204, 511);
            this.c94.Name = "c94";
            this.c94.Size = new System.Drawing.Size(40, 40);
            this.c94.TabIndex = 197;
            this.c94.UseVisualStyleBackColor = true;
            this.c94.Click += new System.EventHandler(this.GuessClick);
            // 
            // c91
            // 
            this.c91.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c91.Location = new System.Drawing.Point(66, 511);
            this.c91.Name = "c91";
            this.c91.Size = new System.Drawing.Size(40, 40);
            this.c91.TabIndex = 196;
            this.c91.UseVisualStyleBackColor = true;
            this.c91.Click += new System.EventHandler(this.GuessClick);
            // 
            // c90
            // 
            this.c90.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c90.Location = new System.Drawing.Point(20, 511);
            this.c90.Name = "c90";
            this.c90.Size = new System.Drawing.Size(40, 40);
            this.c90.TabIndex = 195;
            this.c90.UseVisualStyleBackColor = true;
            this.c90.Click += new System.EventHandler(this.GuessClick);
            // 
            // c97
            // 
            this.c97.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c97.Location = new System.Drawing.Point(342, 511);
            this.c97.Name = "c97";
            this.c97.Size = new System.Drawing.Size(40, 40);
            this.c97.TabIndex = 194;
            this.c97.UseVisualStyleBackColor = true;
            this.c97.Click += new System.EventHandler(this.GuessClick);
            // 
            // c98
            // 
            this.c98.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c98.Location = new System.Drawing.Point(388, 511);
            this.c98.Name = "c98";
            this.c98.Size = new System.Drawing.Size(40, 40);
            this.c98.TabIndex = 193;
            this.c98.UseVisualStyleBackColor = true;
            this.c98.Click += new System.EventHandler(this.GuessClick);
            // 
            // c99
            // 
            this.c99.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c99.Location = new System.Drawing.Point(434, 511);
            this.c99.Name = "c99";
            this.c99.Size = new System.Drawing.Size(40, 40);
            this.c99.TabIndex = 192;
            this.c99.UseVisualStyleBackColor = true;
            this.c99.Click += new System.EventHandler(this.GuessClick);
            // 
            // c96
            // 
            this.c96.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c96.Location = new System.Drawing.Point(296, 511);
            this.c96.Name = "c96";
            this.c96.Size = new System.Drawing.Size(40, 40);
            this.c96.TabIndex = 191;
            this.c96.UseVisualStyleBackColor = true;
            this.c96.Click += new System.EventHandler(this.GuessClick);
            // 
            // c95
            // 
            this.c95.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c95.Location = new System.Drawing.Point(250, 511);
            this.c95.Name = "c95";
            this.c95.Size = new System.Drawing.Size(40, 40);
            this.c95.TabIndex = 190;
            this.c95.UseVisualStyleBackColor = true;
            this.c95.Click += new System.EventHandler(this.GuessClick);
            // 
            // c82
            // 
            this.c82.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c82.Location = new System.Drawing.Point(112, 465);
            this.c82.Name = "c82";
            this.c82.Size = new System.Drawing.Size(40, 40);
            this.c82.TabIndex = 189;
            this.c82.UseVisualStyleBackColor = true;
            this.c82.Click += new System.EventHandler(this.GuessClick);
            // 
            // c83
            // 
            this.c83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c83.Location = new System.Drawing.Point(158, 465);
            this.c83.Name = "c83";
            this.c83.Size = new System.Drawing.Size(40, 40);
            this.c83.TabIndex = 188;
            this.c83.UseVisualStyleBackColor = true;
            this.c83.Click += new System.EventHandler(this.GuessClick);
            // 
            // c84
            // 
            this.c84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c84.Location = new System.Drawing.Point(204, 465);
            this.c84.Name = "c84";
            this.c84.Size = new System.Drawing.Size(40, 40);
            this.c84.TabIndex = 187;
            this.c84.UseVisualStyleBackColor = true;
            this.c84.Click += new System.EventHandler(this.GuessClick);
            // 
            // c81
            // 
            this.c81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c81.Location = new System.Drawing.Point(66, 465);
            this.c81.Name = "c81";
            this.c81.Size = new System.Drawing.Size(40, 40);
            this.c81.TabIndex = 186;
            this.c81.UseVisualStyleBackColor = true;
            this.c81.Click += new System.EventHandler(this.GuessClick);
            // 
            // c80
            // 
            this.c80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c80.Location = new System.Drawing.Point(20, 465);
            this.c80.Name = "c80";
            this.c80.Size = new System.Drawing.Size(40, 40);
            this.c80.TabIndex = 185;
            this.c80.UseVisualStyleBackColor = true;
            this.c80.Click += new System.EventHandler(this.GuessClick);
            // 
            // c87
            // 
            this.c87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c87.Location = new System.Drawing.Point(342, 465);
            this.c87.Name = "c87";
            this.c87.Size = new System.Drawing.Size(40, 40);
            this.c87.TabIndex = 184;
            this.c87.UseVisualStyleBackColor = true;
            this.c87.Click += new System.EventHandler(this.GuessClick);
            // 
            // c88
            // 
            this.c88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c88.Location = new System.Drawing.Point(388, 465);
            this.c88.Name = "c88";
            this.c88.Size = new System.Drawing.Size(40, 40);
            this.c88.TabIndex = 183;
            this.c88.UseVisualStyleBackColor = true;
            this.c88.Click += new System.EventHandler(this.GuessClick);
            // 
            // c89
            // 
            this.c89.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c89.Location = new System.Drawing.Point(434, 465);
            this.c89.Name = "c89";
            this.c89.Size = new System.Drawing.Size(40, 40);
            this.c89.TabIndex = 182;
            this.c89.UseVisualStyleBackColor = true;
            this.c89.Click += new System.EventHandler(this.GuessClick);
            // 
            // c86
            // 
            this.c86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c86.Location = new System.Drawing.Point(296, 465);
            this.c86.Name = "c86";
            this.c86.Size = new System.Drawing.Size(40, 40);
            this.c86.TabIndex = 181;
            this.c86.UseVisualStyleBackColor = true;
            this.c86.Click += new System.EventHandler(this.GuessClick);
            // 
            // c85
            // 
            this.c85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c85.Location = new System.Drawing.Point(250, 465);
            this.c85.Name = "c85";
            this.c85.Size = new System.Drawing.Size(40, 40);
            this.c85.TabIndex = 180;
            this.c85.UseVisualStyleBackColor = true;
            this.c85.Click += new System.EventHandler(this.GuessClick);
            // 
            // c72
            // 
            this.c72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c72.Location = new System.Drawing.Point(112, 419);
            this.c72.Name = "c72";
            this.c72.Size = new System.Drawing.Size(40, 40);
            this.c72.TabIndex = 179;
            this.c72.UseVisualStyleBackColor = true;
            this.c72.Click += new System.EventHandler(this.GuessClick);
            // 
            // c73
            // 
            this.c73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c73.Location = new System.Drawing.Point(158, 419);
            this.c73.Name = "c73";
            this.c73.Size = new System.Drawing.Size(40, 40);
            this.c73.TabIndex = 178;
            this.c73.UseVisualStyleBackColor = true;
            this.c73.Click += new System.EventHandler(this.GuessClick);
            // 
            // c74
            // 
            this.c74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c74.Location = new System.Drawing.Point(204, 419);
            this.c74.Name = "c74";
            this.c74.Size = new System.Drawing.Size(40, 40);
            this.c74.TabIndex = 177;
            this.c74.UseVisualStyleBackColor = true;
            this.c74.Click += new System.EventHandler(this.GuessClick);
            // 
            // c71
            // 
            this.c71.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c71.Location = new System.Drawing.Point(66, 419);
            this.c71.Name = "c71";
            this.c71.Size = new System.Drawing.Size(40, 40);
            this.c71.TabIndex = 176;
            this.c71.UseVisualStyleBackColor = true;
            this.c71.Click += new System.EventHandler(this.GuessClick);
            // 
            // c70
            // 
            this.c70.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c70.Location = new System.Drawing.Point(20, 419);
            this.c70.Name = "c70";
            this.c70.Size = new System.Drawing.Size(40, 40);
            this.c70.TabIndex = 175;
            this.c70.UseVisualStyleBackColor = true;
            this.c70.Click += new System.EventHandler(this.GuessClick);
            // 
            // c77
            // 
            this.c77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c77.Location = new System.Drawing.Point(342, 419);
            this.c77.Name = "c77";
            this.c77.Size = new System.Drawing.Size(40, 40);
            this.c77.TabIndex = 174;
            this.c77.UseVisualStyleBackColor = true;
            this.c77.Click += new System.EventHandler(this.GuessClick);
            // 
            // c78
            // 
            this.c78.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c78.Location = new System.Drawing.Point(388, 419);
            this.c78.Name = "c78";
            this.c78.Size = new System.Drawing.Size(40, 40);
            this.c78.TabIndex = 173;
            this.c78.UseVisualStyleBackColor = true;
            this.c78.Click += new System.EventHandler(this.GuessClick);
            // 
            // c79
            // 
            this.c79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c79.Location = new System.Drawing.Point(434, 419);
            this.c79.Name = "c79";
            this.c79.Size = new System.Drawing.Size(40, 40);
            this.c79.TabIndex = 172;
            this.c79.UseVisualStyleBackColor = true;
            this.c79.Click += new System.EventHandler(this.GuessClick);
            // 
            // c76
            // 
            this.c76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c76.Location = new System.Drawing.Point(296, 419);
            this.c76.Name = "c76";
            this.c76.Size = new System.Drawing.Size(40, 40);
            this.c76.TabIndex = 171;
            this.c76.UseVisualStyleBackColor = true;
            this.c76.Click += new System.EventHandler(this.GuessClick);
            // 
            // c75
            // 
            this.c75.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c75.Location = new System.Drawing.Point(250, 419);
            this.c75.Name = "c75";
            this.c75.Size = new System.Drawing.Size(40, 40);
            this.c75.TabIndex = 170;
            this.c75.UseVisualStyleBackColor = true;
            this.c75.Click += new System.EventHandler(this.GuessClick);
            // 
            // c62
            // 
            this.c62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c62.Location = new System.Drawing.Point(112, 373);
            this.c62.Name = "c62";
            this.c62.Size = new System.Drawing.Size(40, 40);
            this.c62.TabIndex = 169;
            this.c62.UseVisualStyleBackColor = true;
            this.c62.Click += new System.EventHandler(this.GuessClick);
            // 
            // c63
            // 
            this.c63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c63.Location = new System.Drawing.Point(158, 373);
            this.c63.Name = "c63";
            this.c63.Size = new System.Drawing.Size(40, 40);
            this.c63.TabIndex = 168;
            this.c63.UseVisualStyleBackColor = true;
            this.c63.Click += new System.EventHandler(this.GuessClick);
            // 
            // c64
            // 
            this.c64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c64.Location = new System.Drawing.Point(204, 373);
            this.c64.Name = "c64";
            this.c64.Size = new System.Drawing.Size(40, 40);
            this.c64.TabIndex = 167;
            this.c64.UseVisualStyleBackColor = true;
            this.c64.Click += new System.EventHandler(this.GuessClick);
            // 
            // c61
            // 
            this.c61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c61.Location = new System.Drawing.Point(66, 373);
            this.c61.Name = "c61";
            this.c61.Size = new System.Drawing.Size(40, 40);
            this.c61.TabIndex = 166;
            this.c61.UseVisualStyleBackColor = true;
            this.c61.Click += new System.EventHandler(this.GuessClick);
            // 
            // c60
            // 
            this.c60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c60.Location = new System.Drawing.Point(20, 373);
            this.c60.Name = "c60";
            this.c60.Size = new System.Drawing.Size(40, 40);
            this.c60.TabIndex = 165;
            this.c60.UseVisualStyleBackColor = true;
            this.c60.Click += new System.EventHandler(this.GuessClick);
            // 
            // c67
            // 
            this.c67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c67.Location = new System.Drawing.Point(342, 373);
            this.c67.Name = "c67";
            this.c67.Size = new System.Drawing.Size(40, 40);
            this.c67.TabIndex = 164;
            this.c67.UseVisualStyleBackColor = true;
            this.c67.Click += new System.EventHandler(this.GuessClick);
            // 
            // c68
            // 
            this.c68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c68.Location = new System.Drawing.Point(388, 373);
            this.c68.Name = "c68";
            this.c68.Size = new System.Drawing.Size(40, 40);
            this.c68.TabIndex = 163;
            this.c68.UseVisualStyleBackColor = true;
            this.c68.Click += new System.EventHandler(this.GuessClick);
            // 
            // c69
            // 
            this.c69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c69.Location = new System.Drawing.Point(434, 373);
            this.c69.Name = "c69";
            this.c69.Size = new System.Drawing.Size(40, 40);
            this.c69.TabIndex = 162;
            this.c69.UseVisualStyleBackColor = true;
            this.c69.Click += new System.EventHandler(this.GuessClick);
            // 
            // c66
            // 
            this.c66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c66.Location = new System.Drawing.Point(296, 373);
            this.c66.Name = "c66";
            this.c66.Size = new System.Drawing.Size(40, 40);
            this.c66.TabIndex = 161;
            this.c66.UseVisualStyleBackColor = true;
            this.c66.Click += new System.EventHandler(this.GuessClick);
            // 
            // c65
            // 
            this.c65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c65.Location = new System.Drawing.Point(250, 373);
            this.c65.Name = "c65";
            this.c65.Size = new System.Drawing.Size(40, 40);
            this.c65.TabIndex = 160;
            this.c65.UseVisualStyleBackColor = true;
            this.c65.Click += new System.EventHandler(this.GuessClick);
            // 
            // c52
            // 
            this.c52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c52.Location = new System.Drawing.Point(112, 327);
            this.c52.Name = "c52";
            this.c52.Size = new System.Drawing.Size(40, 40);
            this.c52.TabIndex = 159;
            this.c52.UseVisualStyleBackColor = true;
            this.c52.Click += new System.EventHandler(this.GuessClick);
            // 
            // c53
            // 
            this.c53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c53.Location = new System.Drawing.Point(158, 327);
            this.c53.Name = "c53";
            this.c53.Size = new System.Drawing.Size(40, 40);
            this.c53.TabIndex = 158;
            this.c53.UseVisualStyleBackColor = true;
            this.c53.Click += new System.EventHandler(this.GuessClick);
            // 
            // c54
            // 
            this.c54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c54.Location = new System.Drawing.Point(204, 327);
            this.c54.Name = "c54";
            this.c54.Size = new System.Drawing.Size(40, 40);
            this.c54.TabIndex = 157;
            this.c54.UseVisualStyleBackColor = true;
            this.c54.Click += new System.EventHandler(this.GuessClick);
            // 
            // c51
            // 
            this.c51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c51.Location = new System.Drawing.Point(66, 327);
            this.c51.Name = "c51";
            this.c51.Size = new System.Drawing.Size(40, 40);
            this.c51.TabIndex = 156;
            this.c51.UseVisualStyleBackColor = true;
            this.c51.Click += new System.EventHandler(this.GuessClick);
            // 
            // c50
            // 
            this.c50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c50.Location = new System.Drawing.Point(20, 327);
            this.c50.Name = "c50";
            this.c50.Size = new System.Drawing.Size(40, 40);
            this.c50.TabIndex = 155;
            this.c50.UseVisualStyleBackColor = true;
            this.c50.Click += new System.EventHandler(this.GuessClick);
            // 
            // c57
            // 
            this.c57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c57.Location = new System.Drawing.Point(342, 327);
            this.c57.Name = "c57";
            this.c57.Size = new System.Drawing.Size(40, 40);
            this.c57.TabIndex = 154;
            this.c57.UseVisualStyleBackColor = true;
            this.c57.Click += new System.EventHandler(this.GuessClick);
            // 
            // c58
            // 
            this.c58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c58.Location = new System.Drawing.Point(388, 327);
            this.c58.Name = "c58";
            this.c58.Size = new System.Drawing.Size(40, 40);
            this.c58.TabIndex = 153;
            this.c58.UseVisualStyleBackColor = true;
            this.c58.Click += new System.EventHandler(this.GuessClick);
            // 
            // c59
            // 
            this.c59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c59.Location = new System.Drawing.Point(434, 327);
            this.c59.Name = "c59";
            this.c59.Size = new System.Drawing.Size(40, 40);
            this.c59.TabIndex = 152;
            this.c59.UseVisualStyleBackColor = true;
            this.c59.Click += new System.EventHandler(this.GuessClick);
            // 
            // c56
            // 
            this.c56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c56.Location = new System.Drawing.Point(296, 327);
            this.c56.Name = "c56";
            this.c56.Size = new System.Drawing.Size(40, 40);
            this.c56.TabIndex = 151;
            this.c56.UseVisualStyleBackColor = true;
            this.c56.Click += new System.EventHandler(this.GuessClick);
            // 
            // c55
            // 
            this.c55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c55.Location = new System.Drawing.Point(250, 327);
            this.c55.Name = "c55";
            this.c55.Size = new System.Drawing.Size(40, 40);
            this.c55.TabIndex = 150;
            this.c55.UseVisualStyleBackColor = true;
            this.c55.Click += new System.EventHandler(this.GuessClick);
            // 
            // c42
            // 
            this.c42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c42.Location = new System.Drawing.Point(112, 281);
            this.c42.Name = "c42";
            this.c42.Size = new System.Drawing.Size(40, 40);
            this.c42.TabIndex = 149;
            this.c42.UseVisualStyleBackColor = true;
            this.c42.Click += new System.EventHandler(this.GuessClick);
            // 
            // c43
            // 
            this.c43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c43.Location = new System.Drawing.Point(158, 281);
            this.c43.Name = "c43";
            this.c43.Size = new System.Drawing.Size(40, 40);
            this.c43.TabIndex = 148;
            this.c43.UseVisualStyleBackColor = true;
            this.c43.Click += new System.EventHandler(this.GuessClick);
            // 
            // c44
            // 
            this.c44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c44.Location = new System.Drawing.Point(204, 281);
            this.c44.Name = "c44";
            this.c44.Size = new System.Drawing.Size(40, 40);
            this.c44.TabIndex = 147;
            this.c44.UseVisualStyleBackColor = true;
            this.c44.Click += new System.EventHandler(this.GuessClick);
            // 
            // c41
            // 
            this.c41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c41.Location = new System.Drawing.Point(66, 281);
            this.c41.Name = "c41";
            this.c41.Size = new System.Drawing.Size(40, 40);
            this.c41.TabIndex = 146;
            this.c41.UseVisualStyleBackColor = true;
            this.c41.Click += new System.EventHandler(this.GuessClick);
            // 
            // c40
            // 
            this.c40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c40.Location = new System.Drawing.Point(20, 281);
            this.c40.Name = "c40";
            this.c40.Size = new System.Drawing.Size(40, 40);
            this.c40.TabIndex = 145;
            this.c40.UseVisualStyleBackColor = true;
            this.c40.Click += new System.EventHandler(this.GuessClick);
            // 
            // c47
            // 
            this.c47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c47.Location = new System.Drawing.Point(342, 281);
            this.c47.Name = "c47";
            this.c47.Size = new System.Drawing.Size(40, 40);
            this.c47.TabIndex = 144;
            this.c47.UseVisualStyleBackColor = true;
            this.c47.Click += new System.EventHandler(this.GuessClick);
            // 
            // c48
            // 
            this.c48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c48.Location = new System.Drawing.Point(388, 281);
            this.c48.Name = "c48";
            this.c48.Size = new System.Drawing.Size(40, 40);
            this.c48.TabIndex = 143;
            this.c48.UseVisualStyleBackColor = true;
            this.c48.Click += new System.EventHandler(this.GuessClick);
            // 
            // c49
            // 
            this.c49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c49.Location = new System.Drawing.Point(434, 281);
            this.c49.Name = "c49";
            this.c49.Size = new System.Drawing.Size(40, 40);
            this.c49.TabIndex = 142;
            this.c49.UseVisualStyleBackColor = true;
            this.c49.Click += new System.EventHandler(this.GuessClick);
            // 
            // c46
            // 
            this.c46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c46.Location = new System.Drawing.Point(296, 281);
            this.c46.Name = "c46";
            this.c46.Size = new System.Drawing.Size(40, 40);
            this.c46.TabIndex = 141;
            this.c46.UseVisualStyleBackColor = true;
            this.c46.Click += new System.EventHandler(this.GuessClick);
            // 
            // c45
            // 
            this.c45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c45.Location = new System.Drawing.Point(250, 281);
            this.c45.Name = "c45";
            this.c45.Size = new System.Drawing.Size(40, 40);
            this.c45.TabIndex = 140;
            this.c45.UseVisualStyleBackColor = true;
            this.c45.Click += new System.EventHandler(this.GuessClick);
            // 
            // c32
            // 
            this.c32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c32.Location = new System.Drawing.Point(112, 235);
            this.c32.Name = "c32";
            this.c32.Size = new System.Drawing.Size(40, 40);
            this.c32.TabIndex = 139;
            this.c32.UseVisualStyleBackColor = true;
            this.c32.Click += new System.EventHandler(this.GuessClick);
            // 
            // c33
            // 
            this.c33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c33.Location = new System.Drawing.Point(158, 235);
            this.c33.Name = "c33";
            this.c33.Size = new System.Drawing.Size(40, 40);
            this.c33.TabIndex = 138;
            this.c33.UseVisualStyleBackColor = true;
            this.c33.Click += new System.EventHandler(this.GuessClick);
            // 
            // c34
            // 
            this.c34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c34.Location = new System.Drawing.Point(204, 235);
            this.c34.Name = "c34";
            this.c34.Size = new System.Drawing.Size(40, 40);
            this.c34.TabIndex = 137;
            this.c34.UseVisualStyleBackColor = true;
            this.c34.Click += new System.EventHandler(this.GuessClick);
            // 
            // c31
            // 
            this.c31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c31.Location = new System.Drawing.Point(66, 235);
            this.c31.Name = "c31";
            this.c31.Size = new System.Drawing.Size(40, 40);
            this.c31.TabIndex = 136;
            this.c31.UseVisualStyleBackColor = true;
            this.c31.Click += new System.EventHandler(this.GuessClick);
            // 
            // c30
            // 
            this.c30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c30.Location = new System.Drawing.Point(20, 235);
            this.c30.Name = "c30";
            this.c30.Size = new System.Drawing.Size(40, 40);
            this.c30.TabIndex = 135;
            this.c30.UseVisualStyleBackColor = true;
            this.c30.Click += new System.EventHandler(this.GuessClick);
            // 
            // c37
            // 
            this.c37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c37.Location = new System.Drawing.Point(342, 235);
            this.c37.Name = "c37";
            this.c37.Size = new System.Drawing.Size(40, 40);
            this.c37.TabIndex = 134;
            this.c37.UseVisualStyleBackColor = true;
            this.c37.Click += new System.EventHandler(this.GuessClick);
            // 
            // c38
            // 
            this.c38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c38.Location = new System.Drawing.Point(388, 235);
            this.c38.Name = "c38";
            this.c38.Size = new System.Drawing.Size(40, 40);
            this.c38.TabIndex = 133;
            this.c38.UseVisualStyleBackColor = true;
            this.c38.Click += new System.EventHandler(this.GuessClick);
            // 
            // c39
            // 
            this.c39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c39.Location = new System.Drawing.Point(434, 235);
            this.c39.Name = "c39";
            this.c39.Size = new System.Drawing.Size(40, 40);
            this.c39.TabIndex = 132;
            this.c39.UseVisualStyleBackColor = true;
            this.c39.Click += new System.EventHandler(this.GuessClick);
            // 
            // c36
            // 
            this.c36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c36.Location = new System.Drawing.Point(296, 235);
            this.c36.Name = "c36";
            this.c36.Size = new System.Drawing.Size(40, 40);
            this.c36.TabIndex = 131;
            this.c36.UseVisualStyleBackColor = true;
            this.c36.Click += new System.EventHandler(this.GuessClick);
            // 
            // c35
            // 
            this.c35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c35.Location = new System.Drawing.Point(250, 235);
            this.c35.Name = "c35";
            this.c35.Size = new System.Drawing.Size(40, 40);
            this.c35.TabIndex = 130;
            this.c35.UseVisualStyleBackColor = true;
            this.c35.Click += new System.EventHandler(this.GuessClick);
            // 
            // c22
            // 
            this.c22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c22.Location = new System.Drawing.Point(112, 189);
            this.c22.Name = "c22";
            this.c22.Size = new System.Drawing.Size(40, 40);
            this.c22.TabIndex = 129;
            this.c22.UseVisualStyleBackColor = true;
            this.c22.Click += new System.EventHandler(this.GuessClick);
            // 
            // c23
            // 
            this.c23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c23.Location = new System.Drawing.Point(158, 189);
            this.c23.Name = "c23";
            this.c23.Size = new System.Drawing.Size(40, 40);
            this.c23.TabIndex = 128;
            this.c23.UseVisualStyleBackColor = true;
            this.c23.Click += new System.EventHandler(this.GuessClick);
            // 
            // c24
            // 
            this.c24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c24.Location = new System.Drawing.Point(204, 189);
            this.c24.Name = "c24";
            this.c24.Size = new System.Drawing.Size(40, 40);
            this.c24.TabIndex = 127;
            this.c24.UseVisualStyleBackColor = true;
            this.c24.Click += new System.EventHandler(this.GuessClick);
            // 
            // c21
            // 
            this.c21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c21.Location = new System.Drawing.Point(66, 189);
            this.c21.Name = "c21";
            this.c21.Size = new System.Drawing.Size(40, 40);
            this.c21.TabIndex = 126;
            this.c21.UseVisualStyleBackColor = true;
            this.c21.Click += new System.EventHandler(this.GuessClick);
            // 
            // c20
            // 
            this.c20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c20.Location = new System.Drawing.Point(20, 189);
            this.c20.Name = "c20";
            this.c20.Size = new System.Drawing.Size(40, 40);
            this.c20.TabIndex = 125;
            this.c20.UseVisualStyleBackColor = true;
            this.c20.Click += new System.EventHandler(this.GuessClick);
            // 
            // c27
            // 
            this.c27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c27.Location = new System.Drawing.Point(342, 189);
            this.c27.Name = "c27";
            this.c27.Size = new System.Drawing.Size(40, 40);
            this.c27.TabIndex = 124;
            this.c27.UseVisualStyleBackColor = true;
            this.c27.Click += new System.EventHandler(this.GuessClick);
            // 
            // c28
            // 
            this.c28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c28.Location = new System.Drawing.Point(388, 189);
            this.c28.Name = "c28";
            this.c28.Size = new System.Drawing.Size(40, 40);
            this.c28.TabIndex = 123;
            this.c28.UseVisualStyleBackColor = true;
            this.c28.Click += new System.EventHandler(this.GuessClick);
            // 
            // c29
            // 
            this.c29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c29.Location = new System.Drawing.Point(434, 189);
            this.c29.Name = "c29";
            this.c29.Size = new System.Drawing.Size(40, 40);
            this.c29.TabIndex = 122;
            this.c29.UseVisualStyleBackColor = true;
            this.c29.Click += new System.EventHandler(this.GuessClick);
            // 
            // c26
            // 
            this.c26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c26.Location = new System.Drawing.Point(296, 189);
            this.c26.Name = "c26";
            this.c26.Size = new System.Drawing.Size(40, 40);
            this.c26.TabIndex = 121;
            this.c26.UseVisualStyleBackColor = true;
            this.c26.Click += new System.EventHandler(this.GuessClick);
            // 
            // c25
            // 
            this.c25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c25.Location = new System.Drawing.Point(250, 189);
            this.c25.Name = "c25";
            this.c25.Size = new System.Drawing.Size(40, 40);
            this.c25.TabIndex = 120;
            this.c25.UseVisualStyleBackColor = true;
            this.c25.Click += new System.EventHandler(this.GuessClick);
            // 
            // c12
            // 
            this.c12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c12.Location = new System.Drawing.Point(112, 143);
            this.c12.Name = "c12";
            this.c12.Size = new System.Drawing.Size(40, 40);
            this.c12.TabIndex = 119;
            this.c12.UseVisualStyleBackColor = true;
            this.c12.Click += new System.EventHandler(this.GuessClick);
            // 
            // c13
            // 
            this.c13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c13.Location = new System.Drawing.Point(158, 143);
            this.c13.Name = "c13";
            this.c13.Size = new System.Drawing.Size(40, 40);
            this.c13.TabIndex = 118;
            this.c13.UseVisualStyleBackColor = true;
            this.c13.Click += new System.EventHandler(this.GuessClick);
            // 
            // c14
            // 
            this.c14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c14.Location = new System.Drawing.Point(204, 143);
            this.c14.Name = "c14";
            this.c14.Size = new System.Drawing.Size(40, 40);
            this.c14.TabIndex = 117;
            this.c14.UseVisualStyleBackColor = true;
            this.c14.Click += new System.EventHandler(this.GuessClick);
            // 
            // c11
            // 
            this.c11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c11.Location = new System.Drawing.Point(66, 143);
            this.c11.Name = "c11";
            this.c11.Size = new System.Drawing.Size(40, 40);
            this.c11.TabIndex = 116;
            this.c11.UseVisualStyleBackColor = true;
            this.c11.Click += new System.EventHandler(this.GuessClick);
            // 
            // c10
            // 
            this.c10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c10.Location = new System.Drawing.Point(20, 143);
            this.c10.Name = "c10";
            this.c10.Size = new System.Drawing.Size(40, 40);
            this.c10.TabIndex = 115;
            this.c10.UseVisualStyleBackColor = true;
            this.c10.Click += new System.EventHandler(this.GuessClick);
            // 
            // c17
            // 
            this.c17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c17.Location = new System.Drawing.Point(342, 143);
            this.c17.Name = "c17";
            this.c17.Size = new System.Drawing.Size(40, 40);
            this.c17.TabIndex = 114;
            this.c17.UseVisualStyleBackColor = true;
            this.c17.Click += new System.EventHandler(this.GuessClick);
            // 
            // c18
            // 
            this.c18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c18.Location = new System.Drawing.Point(388, 143);
            this.c18.Name = "c18";
            this.c18.Size = new System.Drawing.Size(40, 40);
            this.c18.TabIndex = 113;
            this.c18.UseVisualStyleBackColor = true;
            this.c18.Click += new System.EventHandler(this.GuessClick);
            // 
            // c19
            // 
            this.c19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c19.Location = new System.Drawing.Point(434, 143);
            this.c19.Name = "c19";
            this.c19.Size = new System.Drawing.Size(40, 40);
            this.c19.TabIndex = 112;
            this.c19.UseVisualStyleBackColor = true;
            this.c19.Click += new System.EventHandler(this.GuessClick);
            // 
            // c16
            // 
            this.c16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c16.Location = new System.Drawing.Point(296, 143);
            this.c16.Name = "c16";
            this.c16.Size = new System.Drawing.Size(40, 40);
            this.c16.TabIndex = 111;
            this.c16.UseVisualStyleBackColor = true;
            this.c16.Click += new System.EventHandler(this.GuessClick);
            // 
            // c15
            // 
            this.c15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c15.Location = new System.Drawing.Point(250, 143);
            this.c15.Name = "c15";
            this.c15.Size = new System.Drawing.Size(40, 40);
            this.c15.TabIndex = 110;
            this.c15.UseVisualStyleBackColor = true;
            this.c15.Click += new System.EventHandler(this.GuessClick);
            // 
            // c02
            // 
            this.c02.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c02.Location = new System.Drawing.Point(112, 97);
            this.c02.Name = "c02";
            this.c02.Size = new System.Drawing.Size(40, 40);
            this.c02.TabIndex = 109;
            this.c02.UseVisualStyleBackColor = true;
            this.c02.Click += new System.EventHandler(this.GuessClick);
            // 
            // c03
            // 
            this.c03.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c03.Location = new System.Drawing.Point(158, 97);
            this.c03.Name = "c03";
            this.c03.Size = new System.Drawing.Size(40, 40);
            this.c03.TabIndex = 108;
            this.c03.UseVisualStyleBackColor = true;
            this.c03.Click += new System.EventHandler(this.GuessClick);
            // 
            // c04
            // 
            this.c04.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c04.Location = new System.Drawing.Point(204, 97);
            this.c04.Name = "c04";
            this.c04.Size = new System.Drawing.Size(40, 40);
            this.c04.TabIndex = 107;
            this.c04.UseVisualStyleBackColor = true;
            this.c04.Click += new System.EventHandler(this.GuessClick);
            // 
            // c01
            // 
            this.c01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c01.Location = new System.Drawing.Point(66, 97);
            this.c01.Name = "c01";
            this.c01.Size = new System.Drawing.Size(40, 40);
            this.c01.TabIndex = 106;
            this.c01.UseVisualStyleBackColor = true;
            this.c01.Click += new System.EventHandler(this.GuessClick);
            // 
            // c00
            // 
            this.c00.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c00.Location = new System.Drawing.Point(20, 97);
            this.c00.Name = "c00";
            this.c00.Size = new System.Drawing.Size(40, 40);
            this.c00.TabIndex = 105;
            this.c00.UseVisualStyleBackColor = true;
            this.c00.Click += new System.EventHandler(this.GuessClick);
            // 
            // c07
            // 
            this.c07.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c07.Location = new System.Drawing.Point(342, 97);
            this.c07.Name = "c07";
            this.c07.Size = new System.Drawing.Size(40, 40);
            this.c07.TabIndex = 104;
            this.c07.UseVisualStyleBackColor = true;
            this.c07.Click += new System.EventHandler(this.GuessClick);
            // 
            // c08
            // 
            this.c08.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c08.Location = new System.Drawing.Point(388, 97);
            this.c08.Name = "c08";
            this.c08.Size = new System.Drawing.Size(40, 40);
            this.c08.TabIndex = 103;
            this.c08.UseVisualStyleBackColor = true;
            this.c08.Click += new System.EventHandler(this.GuessClick);
            // 
            // c09
            // 
            this.c09.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c09.Location = new System.Drawing.Point(434, 97);
            this.c09.Name = "c09";
            this.c09.Size = new System.Drawing.Size(40, 40);
            this.c09.TabIndex = 102;
            this.c09.UseVisualStyleBackColor = true;
            this.c09.Click += new System.EventHandler(this.GuessClick);
            // 
            // c06
            // 
            this.c06.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c06.Location = new System.Drawing.Point(296, 97);
            this.c06.Name = "c06";
            this.c06.Size = new System.Drawing.Size(40, 40);
            this.c06.TabIndex = 101;
            this.c06.UseVisualStyleBackColor = true;
            this.c06.Click += new System.EventHandler(this.GuessClick);
            // 
            // c05
            // 
            this.c05.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c05.Location = new System.Drawing.Point(250, 97);
            this.c05.Name = "c05";
            this.c05.Size = new System.Drawing.Size(40, 40);
            this.c05.TabIndex = 100;
            this.c05.UseVisualStyleBackColor = true;
            this.c05.Click += new System.EventHandler(this.GuessClick);
            // 
            // btnRestart
            // 
            this.btnRestart.Location = new System.Drawing.Point(715, 508);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(158, 43);
            this.btnRestart.TabIndex = 201;
            this.btnRestart.Text = "Reset Current Ship";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1098, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 29);
            this.label1.TabIndex = 202;
            this.label1.Text = "Player";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(199, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 29);
            this.label2.TabIndex = 203;
            this.label2.Text = "Computer";
            // 
            // lblCenter
            // 
            this.lblCenter.AutoSize = true;
            this.lblCenter.Location = new System.Drawing.Point(579, 97);
            this.lblCenter.Name = "lblCenter";
            this.lblCenter.Size = new System.Drawing.Size(0, 17);
            this.lblCenter.TabIndex = 204;
            // 
            // lblRemain
            // 
            this.lblRemain.AutoSize = true;
            this.lblRemain.Location = new System.Drawing.Point(579, 178);
            this.lblRemain.Name = "lblRemain";
            this.lblRemain.Size = new System.Drawing.Size(0, 17);
            this.lblRemain.TabIndex = 205;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(500, 508);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 43);
            this.button1.TabIndex = 207;
            this.button1.Text = "How To Play";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(1369, 569);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblRemain);
            this.Controls.Add(this.lblCenter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.c92);
            this.Controls.Add(this.c93);
            this.Controls.Add(this.c94);
            this.Controls.Add(this.c91);
            this.Controls.Add(this.c90);
            this.Controls.Add(this.c97);
            this.Controls.Add(this.c98);
            this.Controls.Add(this.c99);
            this.Controls.Add(this.c96);
            this.Controls.Add(this.c95);
            this.Controls.Add(this.c82);
            this.Controls.Add(this.c83);
            this.Controls.Add(this.c84);
            this.Controls.Add(this.c81);
            this.Controls.Add(this.c80);
            this.Controls.Add(this.c87);
            this.Controls.Add(this.c88);
            this.Controls.Add(this.c89);
            this.Controls.Add(this.c86);
            this.Controls.Add(this.c85);
            this.Controls.Add(this.c72);
            this.Controls.Add(this.c73);
            this.Controls.Add(this.c74);
            this.Controls.Add(this.c71);
            this.Controls.Add(this.c70);
            this.Controls.Add(this.c77);
            this.Controls.Add(this.c78);
            this.Controls.Add(this.c79);
            this.Controls.Add(this.c76);
            this.Controls.Add(this.c75);
            this.Controls.Add(this.c62);
            this.Controls.Add(this.c63);
            this.Controls.Add(this.c64);
            this.Controls.Add(this.c61);
            this.Controls.Add(this.c60);
            this.Controls.Add(this.c67);
            this.Controls.Add(this.c68);
            this.Controls.Add(this.c69);
            this.Controls.Add(this.c66);
            this.Controls.Add(this.c65);
            this.Controls.Add(this.c52);
            this.Controls.Add(this.c53);
            this.Controls.Add(this.c54);
            this.Controls.Add(this.c51);
            this.Controls.Add(this.c50);
            this.Controls.Add(this.c57);
            this.Controls.Add(this.c58);
            this.Controls.Add(this.c59);
            this.Controls.Add(this.c56);
            this.Controls.Add(this.c55);
            this.Controls.Add(this.c42);
            this.Controls.Add(this.c43);
            this.Controls.Add(this.c44);
            this.Controls.Add(this.c41);
            this.Controls.Add(this.c40);
            this.Controls.Add(this.c47);
            this.Controls.Add(this.c48);
            this.Controls.Add(this.c49);
            this.Controls.Add(this.c46);
            this.Controls.Add(this.c45);
            this.Controls.Add(this.c32);
            this.Controls.Add(this.c33);
            this.Controls.Add(this.c34);
            this.Controls.Add(this.c31);
            this.Controls.Add(this.c30);
            this.Controls.Add(this.c37);
            this.Controls.Add(this.c38);
            this.Controls.Add(this.c39);
            this.Controls.Add(this.c36);
            this.Controls.Add(this.c35);
            this.Controls.Add(this.c22);
            this.Controls.Add(this.c23);
            this.Controls.Add(this.c24);
            this.Controls.Add(this.c21);
            this.Controls.Add(this.c20);
            this.Controls.Add(this.c27);
            this.Controls.Add(this.c28);
            this.Controls.Add(this.c29);
            this.Controls.Add(this.c26);
            this.Controls.Add(this.c25);
            this.Controls.Add(this.c12);
            this.Controls.Add(this.c13);
            this.Controls.Add(this.c14);
            this.Controls.Add(this.c11);
            this.Controls.Add(this.c10);
            this.Controls.Add(this.c17);
            this.Controls.Add(this.c18);
            this.Controls.Add(this.c19);
            this.Controls.Add(this.c16);
            this.Controls.Add(this.c15);
            this.Controls.Add(this.c02);
            this.Controls.Add(this.c03);
            this.Controls.Add(this.c04);
            this.Controls.Add(this.c01);
            this.Controls.Add(this.c00);
            this.Controls.Add(this.c07);
            this.Controls.Add(this.c08);
            this.Controls.Add(this.c09);
            this.Controls.Add(this.c06);
            this.Controls.Add(this.c05);
            this.Controls.Add(this.p92);
            this.Controls.Add(this.p93);
            this.Controls.Add(this.p94);
            this.Controls.Add(this.p91);
            this.Controls.Add(this.p90);
            this.Controls.Add(this.p97);
            this.Controls.Add(this.p98);
            this.Controls.Add(this.p99);
            this.Controls.Add(this.p96);
            this.Controls.Add(this.p95);
            this.Controls.Add(this.p82);
            this.Controls.Add(this.p83);
            this.Controls.Add(this.p84);
            this.Controls.Add(this.p81);
            this.Controls.Add(this.p80);
            this.Controls.Add(this.p87);
            this.Controls.Add(this.p88);
            this.Controls.Add(this.p89);
            this.Controls.Add(this.p86);
            this.Controls.Add(this.p85);
            this.Controls.Add(this.p72);
            this.Controls.Add(this.p73);
            this.Controls.Add(this.p74);
            this.Controls.Add(this.p71);
            this.Controls.Add(this.p70);
            this.Controls.Add(this.p77);
            this.Controls.Add(this.p78);
            this.Controls.Add(this.p79);
            this.Controls.Add(this.p76);
            this.Controls.Add(this.p75);
            this.Controls.Add(this.p62);
            this.Controls.Add(this.p63);
            this.Controls.Add(this.p64);
            this.Controls.Add(this.p61);
            this.Controls.Add(this.p60);
            this.Controls.Add(this.p67);
            this.Controls.Add(this.p68);
            this.Controls.Add(this.p69);
            this.Controls.Add(this.p66);
            this.Controls.Add(this.p65);
            this.Controls.Add(this.p52);
            this.Controls.Add(this.p53);
            this.Controls.Add(this.p54);
            this.Controls.Add(this.p51);
            this.Controls.Add(this.p50);
            this.Controls.Add(this.p57);
            this.Controls.Add(this.p58);
            this.Controls.Add(this.p59);
            this.Controls.Add(this.p56);
            this.Controls.Add(this.p55);
            this.Controls.Add(this.p42);
            this.Controls.Add(this.p43);
            this.Controls.Add(this.p44);
            this.Controls.Add(this.p41);
            this.Controls.Add(this.p40);
            this.Controls.Add(this.p47);
            this.Controls.Add(this.p48);
            this.Controls.Add(this.p49);
            this.Controls.Add(this.p46);
            this.Controls.Add(this.p45);
            this.Controls.Add(this.p32);
            this.Controls.Add(this.p33);
            this.Controls.Add(this.p34);
            this.Controls.Add(this.p31);
            this.Controls.Add(this.p30);
            this.Controls.Add(this.p37);
            this.Controls.Add(this.p38);
            this.Controls.Add(this.p39);
            this.Controls.Add(this.p36);
            this.Controls.Add(this.p35);
            this.Controls.Add(this.p22);
            this.Controls.Add(this.p23);
            this.Controls.Add(this.p24);
            this.Controls.Add(this.p21);
            this.Controls.Add(this.p20);
            this.Controls.Add(this.p27);
            this.Controls.Add(this.p28);
            this.Controls.Add(this.p29);
            this.Controls.Add(this.p26);
            this.Controls.Add(this.p25);
            this.Controls.Add(this.p12);
            this.Controls.Add(this.p13);
            this.Controls.Add(this.p14);
            this.Controls.Add(this.p11);
            this.Controls.Add(this.p10);
            this.Controls.Add(this.p17);
            this.Controls.Add(this.p18);
            this.Controls.Add(this.p19);
            this.Controls.Add(this.p16);
            this.Controls.Add(this.p15);
            this.Controls.Add(this.p02);
            this.Controls.Add(this.p03);
            this.Controls.Add(this.p04);
            this.Controls.Add(this.p01);
            this.Controls.Add(this.p00);
            this.Controls.Add(this.p07);
            this.Controls.Add(this.p08);
            this.Controls.Add(this.p09);
            this.Controls.Add(this.p06);
            this.Controls.Add(this.p05);
            this.Name = "Game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button p05;
        private System.Windows.Forms.Button p06;
        private System.Windows.Forms.Button p09;
        private System.Windows.Forms.Button p08;
        private System.Windows.Forms.Button p07;
        private System.Windows.Forms.Button p02;
        private System.Windows.Forms.Button p03;
        private System.Windows.Forms.Button p04;
        private System.Windows.Forms.Button p01;
        private System.Windows.Forms.Button p00;
        private System.Windows.Forms.Button p12;
        private System.Windows.Forms.Button p13;
        private System.Windows.Forms.Button p14;
        private System.Windows.Forms.Button p11;
        private System.Windows.Forms.Button p10;
        private System.Windows.Forms.Button p17;
        private System.Windows.Forms.Button p18;
        private System.Windows.Forms.Button p19;
        private System.Windows.Forms.Button p16;
        private System.Windows.Forms.Button p15;
        private System.Windows.Forms.Button p22;
        private System.Windows.Forms.Button p23;
        private System.Windows.Forms.Button p24;
        private System.Windows.Forms.Button p21;
        private System.Windows.Forms.Button p20;
        private System.Windows.Forms.Button p27;
        private System.Windows.Forms.Button p28;
        private System.Windows.Forms.Button p29;
        private System.Windows.Forms.Button p26;
        private System.Windows.Forms.Button p25;
        private System.Windows.Forms.Button p32;
        private System.Windows.Forms.Button p33;
        private System.Windows.Forms.Button p34;
        private System.Windows.Forms.Button p31;
        private System.Windows.Forms.Button p30;
        private System.Windows.Forms.Button p37;
        private System.Windows.Forms.Button p38;
        private System.Windows.Forms.Button p39;
        private System.Windows.Forms.Button p36;
        private System.Windows.Forms.Button p35;
        private System.Windows.Forms.Button p42;
        private System.Windows.Forms.Button p43;
        private System.Windows.Forms.Button p44;
        private System.Windows.Forms.Button p41;
        private System.Windows.Forms.Button p40;
        private System.Windows.Forms.Button p47;
        private System.Windows.Forms.Button p48;
        private System.Windows.Forms.Button p49;
        private System.Windows.Forms.Button p46;
        private System.Windows.Forms.Button p45;
        private System.Windows.Forms.Button p52;
        private System.Windows.Forms.Button p53;
        private System.Windows.Forms.Button p54;
        private System.Windows.Forms.Button p51;
        private System.Windows.Forms.Button p50;
        private System.Windows.Forms.Button p57;
        private System.Windows.Forms.Button p58;
        private System.Windows.Forms.Button p59;
        private System.Windows.Forms.Button p56;
        private System.Windows.Forms.Button p55;
        private System.Windows.Forms.Button p62;
        private System.Windows.Forms.Button p63;
        private System.Windows.Forms.Button p64;
        private System.Windows.Forms.Button p61;
        private System.Windows.Forms.Button p60;
        private System.Windows.Forms.Button p67;
        private System.Windows.Forms.Button p68;
        private System.Windows.Forms.Button p69;
        private System.Windows.Forms.Button p66;
        private System.Windows.Forms.Button p65;
        private System.Windows.Forms.Button p72;
        private System.Windows.Forms.Button p73;
        private System.Windows.Forms.Button p74;
        private System.Windows.Forms.Button p71;
        private System.Windows.Forms.Button p70;
        private System.Windows.Forms.Button p77;
        private System.Windows.Forms.Button p78;
        private System.Windows.Forms.Button p79;
        private System.Windows.Forms.Button p76;
        private System.Windows.Forms.Button p75;
        private System.Windows.Forms.Button p82;
        private System.Windows.Forms.Button p83;
        private System.Windows.Forms.Button p84;
        private System.Windows.Forms.Button p81;
        private System.Windows.Forms.Button p80;
        private System.Windows.Forms.Button p87;
        private System.Windows.Forms.Button p88;
        private System.Windows.Forms.Button p89;
        private System.Windows.Forms.Button p86;
        private System.Windows.Forms.Button p85;
        private System.Windows.Forms.Button p92;
        private System.Windows.Forms.Button p93;
        private System.Windows.Forms.Button p94;
        private System.Windows.Forms.Button p91;
        private System.Windows.Forms.Button p90;
        private System.Windows.Forms.Button p97;
        private System.Windows.Forms.Button p98;
        private System.Windows.Forms.Button p99;
        private System.Windows.Forms.Button p96;
        private System.Windows.Forms.Button p95;
        private System.Windows.Forms.Button c92;
        private System.Windows.Forms.Button c93;
        private System.Windows.Forms.Button c94;
        private System.Windows.Forms.Button c91;
        private System.Windows.Forms.Button c90;
        private System.Windows.Forms.Button c97;
        private System.Windows.Forms.Button c98;
        private System.Windows.Forms.Button c99;
        private System.Windows.Forms.Button c96;
        private System.Windows.Forms.Button c95;
        private System.Windows.Forms.Button c82;
        private System.Windows.Forms.Button c83;
        private System.Windows.Forms.Button c84;
        private System.Windows.Forms.Button c81;
        private System.Windows.Forms.Button c80;
        private System.Windows.Forms.Button c87;
        private System.Windows.Forms.Button c88;
        private System.Windows.Forms.Button c89;
        private System.Windows.Forms.Button c86;
        private System.Windows.Forms.Button c85;
        private System.Windows.Forms.Button c72;
        private System.Windows.Forms.Button c73;
        private System.Windows.Forms.Button c74;
        private System.Windows.Forms.Button c71;
        private System.Windows.Forms.Button c70;
        private System.Windows.Forms.Button c77;
        private System.Windows.Forms.Button c78;
        private System.Windows.Forms.Button c79;
        private System.Windows.Forms.Button c76;
        private System.Windows.Forms.Button c75;
        private System.Windows.Forms.Button c62;
        private System.Windows.Forms.Button c63;
        private System.Windows.Forms.Button c64;
        private System.Windows.Forms.Button c61;
        private System.Windows.Forms.Button c60;
        private System.Windows.Forms.Button c67;
        private System.Windows.Forms.Button c68;
        private System.Windows.Forms.Button c69;
        private System.Windows.Forms.Button c66;
        private System.Windows.Forms.Button c65;
        private System.Windows.Forms.Button c52;
        private System.Windows.Forms.Button c53;
        private System.Windows.Forms.Button c54;
        private System.Windows.Forms.Button c51;
        private System.Windows.Forms.Button c50;
        private System.Windows.Forms.Button c57;
        private System.Windows.Forms.Button c58;
        private System.Windows.Forms.Button c59;
        private System.Windows.Forms.Button c56;
        private System.Windows.Forms.Button c55;
        private System.Windows.Forms.Button c42;
        private System.Windows.Forms.Button c43;
        private System.Windows.Forms.Button c44;
        private System.Windows.Forms.Button c41;
        private System.Windows.Forms.Button c40;
        private System.Windows.Forms.Button c47;
        private System.Windows.Forms.Button c48;
        private System.Windows.Forms.Button c49;
        private System.Windows.Forms.Button c46;
        private System.Windows.Forms.Button c45;
        private System.Windows.Forms.Button c32;
        private System.Windows.Forms.Button c33;
        private System.Windows.Forms.Button c34;
        private System.Windows.Forms.Button c31;
        private System.Windows.Forms.Button c30;
        private System.Windows.Forms.Button c37;
        private System.Windows.Forms.Button c38;
        private System.Windows.Forms.Button c39;
        private System.Windows.Forms.Button c36;
        private System.Windows.Forms.Button c35;
        private System.Windows.Forms.Button c22;
        private System.Windows.Forms.Button c23;
        private System.Windows.Forms.Button c24;
        private System.Windows.Forms.Button c21;
        private System.Windows.Forms.Button c20;
        private System.Windows.Forms.Button c27;
        private System.Windows.Forms.Button c28;
        private System.Windows.Forms.Button c29;
        private System.Windows.Forms.Button c26;
        private System.Windows.Forms.Button c25;
        private System.Windows.Forms.Button c12;
        private System.Windows.Forms.Button c13;
        private System.Windows.Forms.Button c14;
        private System.Windows.Forms.Button c11;
        private System.Windows.Forms.Button c10;
        private System.Windows.Forms.Button c17;
        private System.Windows.Forms.Button c18;
        private System.Windows.Forms.Button c19;
        private System.Windows.Forms.Button c16;
        private System.Windows.Forms.Button c15;
        private System.Windows.Forms.Button c02;
        private System.Windows.Forms.Button c03;
        private System.Windows.Forms.Button c04;
        private System.Windows.Forms.Button c01;
        private System.Windows.Forms.Button c00;
        private System.Windows.Forms.Button c07;
        private System.Windows.Forms.Button c08;
        private System.Windows.Forms.Button c09;
        private System.Windows.Forms.Button c06;
        private System.Windows.Forms.Button c05;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCenter;
        private System.Windows.Forms.Label lblRemain;
        private System.Windows.Forms.Button button1;
    }
}